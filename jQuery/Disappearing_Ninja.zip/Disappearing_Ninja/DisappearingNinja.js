$(document).ready(function() {
    $('img').click(function() {
        $(this).hide();
        
    })
    $('button').click(function(){
        $('img').show();
    })
})
//when image is clicked (this) have it disappear
//When the button is clicked, all images will appear
//$('#wrapper').click(function() 

